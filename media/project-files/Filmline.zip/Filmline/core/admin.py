from django.contrib import admin
from .models import Country, Genre, Person, Movie, Review, Serial, History
# Register your models here.

class CountryAdmin(admin.ModelAdmin):
    list_display = ['country_iso_code', 'country_name','get_country_image']
admin.site.register(Country, CountryAdmin)


class GenreAdmin(admin.ModelAdmin):
    list_display = ['genre_id', 'genre_name']
admin.site.register(Genre, GenreAdmin)


class PersonAdmin(admin.ModelAdmin):
    list_display = ['f_name', 'birth_day', 'get_person_image']
admin.site.register(Person, PersonAdmin)


class MovieAdmin(admin.ModelAdmin):
    list_display = ['title', 'runtime', 'get_movie_image']
admin.site.register(Movie, MovieAdmin)


class SerialAdmin(admin.ModelAdmin):
    list_display = ['title', 'season_num', 'get_serial_image']
admin.site.register(Serial, SerialAdmin)


class ReviewAdmin(admin.ModelAdmin):
    list_display = ['user', 'movie', 'rating', 'get_image']
admin.site.register(Review, ReviewAdmin)


class HistoryAdmin(admin.ModelAdmin):
    list_display = ['user', 'movie', 'get_movie_image']
admin.site.register(History, HistoryAdmin)    
