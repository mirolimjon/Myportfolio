from django.urls import path
from . import views

urlpatterns = [
    path('', views.homeView, name='home'),
    path('movie-detail/<str:pk>/', views.movieDetail, name='movie-detail'),
    path('season-detail/<str:pk>/', views.seasonDetail, name='season-detail'),
    path('all-movies/', views.allMovies, name='allmovies'),
    path('genre-detail/<str:pk>/', views.genreDetail, name='genre-detail'),
    path('history/', views.userHistory, name='history'),
    path('clean-history/', views.clean_History, name='clean_history'),
    path('actors/', views.actorsView, name='actors'),
    path('actor-detail/<str:pk>/', views.actorDetail, name='actor-detail'),
    path('top-rated/', views.topRated, name='toprated'),
    path('search/', views.search_movie, name='search'),
]