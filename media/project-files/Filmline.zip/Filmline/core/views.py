from django.shortcuts import render, redirect
from .models import Movie, Genre, Person, Review, Serial, History
# from django.db.models import Avg
from .forms import CreateReviewForm
from django.db.models import Q

# Create your views here.

def homeView(request):
    movies = Movie.objects.filter(status = 'Single')
    serials = Serial.objects.all()
    context = {
        'movies': movies,
        'serials': serials
    }
    return render(request, 'core/home.html', context)


def movieDetail(request, pk):
    movie = Movie.objects.get(movie_id=pk)
    if request.user.is_authenticated:
        history = History.objects.update_or_create(
            user = request.user,
            movie = movie,
        )
    
    review_form = CreateReviewForm()
    make_review = True
    if request.user.is_authenticated:
        user_review_count = Review.objects.filter(user=request.user, movie=movie).count()
        if user_review_count>0:
            make_review = False        
    if request.method == "POST":
        review = request.POST.get('review')
        rating = request.POST.get('rating')
            
        review = Review.objects.create(
            user=request.user,
            movie=movie,
            review = review,
            rating = rating,
        )
        review.save()
        return redirect('movie-detail', movie.movie_id)
            
    context = {
        'movie': movie,
        'review_form': review_form,
        'make_review': make_review,
    }
    return render(request, 'core/movie-detail.html', context)


def seasonDetail(request, pk):
    serial = Serial.objects.get(serial_id = pk)
    context = {
        'serial': serial
    }
    return render(request, 'core/season_detail.html', context)


def genreDetail(request, pk):
    genre = Genre.objects.get(genre_id = pk)
    context = {
        'genre': genre
    }
    return render(request, 'core/genre-detail.html', context)


def allMovies(request):
    movies = Movie.objects.all()
    context = {
        'movies': movies
    }
    return render(request, 'core/movie-list.html', context)


def userHistory(request):
    history = History.objects.filter(user = request.user)
    context = {
        'history': history,
    }
    return render(request, 'core/history.html', context)


def clean_History(request):
    history = History.objects.filter(user = request.user)
    history.delete()
    return redirect('history')


def actorsView(request):
    actors = Person.objects.all()
    context = {
        'actors': actors
    }
    return render(request, 'core/actors-list.html', context)


def actorDetail(request, pk):
    actor = Person.objects.get(id=pk)
    context = {
        'actor': actor
    }
    return render(request, 'core/actor-detail.html', context)


   
def topRated(request):
    movies = Movie.objects.all()
    return render(request, 'core/toprated.html', {'movies': movies})


def search_movie(request):
    query = request.GET.get('q')    
    movies = Movie.objects.filter(Q(title__icontains=query)|
                                  Q(genre__genre_name__icontains = query))
    
    movies_count = movies.count()
            
    context = {
        'movies': movies,
        'movies_count':movies_count
    }
    return render(request, 'core/search-movies.html', context)
