from django.db import models
from shortuuid.django_fields import ShortUUIDField
from django.utils.html import mark_safe
from account.models import User
from django.db.models import Avg
# Create your models here.


class Country(models.Model):
    country_id = ShortUUIDField(
        length=16,
        max_length=40,
        prefix="id_",
        alphabet="abcdefg1234",
        primary_key=True,
    )
    country_iso_code = models.CharField(max_length=5)
    country_name = models.CharField(max_length=100)
    flag = models.ImageField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.country_name}"
    
    def get_country_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.flag.url))


class Genre(models.Model):
    genre_id = ShortUUIDField(
        length=16,
        max_length=40,
        prefix="id_",
        alphabet="abcdefg1234",
        primary_key=True,
    )
    genre_name = models.CharField(max_length=50)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.genre_name}"
    
    def get_movies_count(self):
        return self.movie_set.count()
    
class Person(models.Model):
    f_name = models.CharField(max_length=100)
    birth_day = models.DateField()
    image = models.ImageField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.f_name}"
    
    def get_person_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.image.url))
    
    def actor_films(self):
        return self.movie_set.all()
    

STATUS_CHOICE = (
    ('Single', 'Single'),
    ('Serial', 'Serial'),
)


class Movie(models.Model):
    movie_id = ShortUUIDField(
        length=16,
        max_length=40,
        prefix="id_",
        alphabet="abcdefg1234",
        primary_key=True,
    )
    title = models.CharField(max_length=200)
    budget = models.IntegerField(blank=True)
    country = models.ForeignKey(Country, on_delete=models.SET_NULL, null=True)
    genre = models.ManyToManyField(Genre)
    status = models.CharField(choices=STATUS_CHOICE, max_length=10)
    overview = models.TextField()
    realise_date = models.DateField()
    revenue = models.IntegerField()
    runtime = models.IntegerField()
    file = models.FileField(blank=True)
    back_img = models.ImageField(default='movie_default.jpg')
    stars = models.ManyToManyField(Person)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.title}"
    
    def get_movie_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.back_img.url))
    
    def get_rating(self):
        get_top = self.review_set.aggregate(rating=Avg('rating'))
        return get_top
    
    
class Serial(models.Model):
    serial_id = ShortUUIDField(
        length=16,
        max_length=40,
        prefix="id_",
        alphabet="abcdefg1234",
        primary_key=True,
    )
    title = models.CharField(max_length=150)
    movie = models.ManyToManyField(Movie)
    season_num = models.IntegerField(default=1)
    overview = models.TextField()
    back_img = models.ImageField(default='serial_img.jpg')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.title}"
    
    def get_serial_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.back_img.url))
    
    def get_all_movies(self):
        return self.movie.all()
    



RATING = (
    (1, '★☆☆☆☆'),
    (2, '★★☆☆☆'),
    (3, '★★★☆☆'),
    (4, '★★★★☆'),
    (5, '★★★★★'),
)

class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    review = models.CharField(max_length=100)
    rating = models.IntegerField(choices=RATING, default=None)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Movie Review"
        ordering = ['-created']

    def __str__(self):
        return self.movie.title
    
    def get_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.movie.back_img.url))


class History(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-updated', '-created']

    def __str__(self):
        return f"{self.user}"
    
    def get_movie_image(self):
        return mark_safe('<img src="%s" width="50" height="50" />' % (self.movie.back_img.url))