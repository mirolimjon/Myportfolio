from .models import Genre


def default(request):
    genres = Genre.objects.all()
    return {'genres': genres}